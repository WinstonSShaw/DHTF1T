package com.DH.DigitalBooking.repositories;
import com.DH.DigitalBooking.models.Reservation;
import com.DH.DigitalBooking.models.Role;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface RoleRepository extends JpaRepository<Role, Object> {
 //TODO


}
