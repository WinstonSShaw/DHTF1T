package com.DH.DigitalBooking.models.entities;

public class Client extends User {




}
